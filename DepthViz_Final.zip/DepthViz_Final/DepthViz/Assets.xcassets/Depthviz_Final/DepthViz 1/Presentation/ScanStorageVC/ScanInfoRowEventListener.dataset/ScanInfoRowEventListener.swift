//
//  Utils.swift
//  DepthViz
//
//  Created by Group 9 on 2024/06/15.
//  Copyright © 2024 Apple. All rights reserved.
//

import Foundation

class ScanInfoRowEventListener: ObservableObject {
    @Published var selectedLidarFileName: String?
}
