// 프로젝트 내 파일 리스트 보기

import SwiftUI
import UIKit

struct ProjectDetailView: View {
    var project: String
    @State private var scanInfos: [ScanInfo] = []
    @State private var showActionSheet = false
    @State private var selectedFile: ScanInfo?
    @State private var showShareSheet = false // 공유 시트 표시 여부
    @State private var showRenameAlert = false // 파일 이름 변경 팝업 표시 여부
    @State private var newFileName = "" // 변경할 파일 이름
    @State private var showFileView = false // 파일 보기 시트 표시 여부

    var body: some View {
        List {
            ForEach(scanInfos, id: \.fileName) { info in
                Button(action: {
                    selectedFile = info
                    showActionSheet = true
                }) {
                    ScanInfoRow(info: info)
                }
            }
            .onDelete(perform: deleteFiles) // 스와이프 삭제 기능 추가
        }
        .onAppear {
            loadScanInfos()
        }
        .actionSheet(isPresented: $showActionSheet) {
            ActionSheet(
                title: Text(selectedFile?.fileName ?? ""),
                buttons: [
                    .default(Text("파일 보기")) {
                        showFileView = true
                    },
                    .default(Text("파일 이름 변경")) {
                        showRenameAlert = true
                    },
                    .default(Text("파일 공유")) {
                        shareFile(file: selectedFile)
                    },
                    .destructive(Text("파일 삭제")) {
                        deleteFile(file: selectedFile)
                    },
                    .cancel()
                ]
            )
        }
        .alert(isPresented: $showRenameAlert) {
            Alert(
                title: Text("파일 이름 변경"),
                message: Text("새 파일 이름을 입력하세요."),
                primaryButton: .default(Text("변경"), action: {
                    renameFile(file: selectedFile, newFileName: newFileName)
                }),
                secondaryButton: .cancel()
            )
        }
        .sheet(isPresented: $showFileView) {
            if let filePath = getFileURL(for: selectedFile)?.path {
                ViewControllerWrapper(filePath: filePath)
            }
        }
        .sheet(isPresented: $showShareSheet) {
            if let fileURL = getFileURL(for: selectedFile) {
                ActivityViewController(activityItems: [fileURL])
            }
        }
        .navigationTitle(project)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func loadScanInfos() {
        // 데이터를 초기화하고 스캔 데이터를 다시 로드
        DispatchQueue.global(qos: .userInitiated).async {
            let loadedInfos = ScanStorage.shared.getFiles(byProject: project)
            DispatchQueue.main.async {
                self.scanInfos = loadedInfos
                print("Loaded Scan Infos: \(loadedInfos)") // 디버그 로그 추가
            }
        }
    }

    private func renameFile(file: ScanInfo?, newFileName: String) {
        guard let file = file else { return }
        ScanStorage.shared.renameFile(oldFileName: file.fileName, newFileName: newFileName)
        loadScanInfos() // 변경 후 목록 업데이트
    }

    private func shareFile(file: ScanInfo?) {
        guard let fileURL = getFileURL(for: file) else { return }
        // 파일이 존재하는 경우 공유 시트를 표시
        showShareSheet = true
    }

    private func getFileURL(for file: ScanInfo?) -> URL? {
        guard let fileName = file?.fileName else { return nil }
        return ScanStorage.shared.fileUrl(fileName: fileName)
    }

    private func deleteFile(file: ScanInfo?) {
        guard let fileName = file?.fileName else { return }
        ScanStorage.shared.remove(fileName: fileName)
        loadScanInfos() // 데이터 갱신
    }
    
    private func deleteFiles(at offsets: IndexSet) {
        for index in offsets {
            let file = scanInfos[index]
            deleteFile(file: file)
        }
    }
}

struct ViewControllerWrapper: UIViewControllerRepresentable {
    var filePath: String
    
    func makeUIViewController(context: Context) -> ViewController {
        let viewController = ViewController()
        return viewController
    }

    func updateUIViewController(_ uiViewController: ViewController, context: Context) {
        uiViewController.READFILE(from: filePath)
    }
}
