//
//  PointCloud.swift
//  DepthViz
//
//  Created by 장민석 on 8/28/24.
//  Copyright © 2024 Apple. All rights reserved.
//


//포인트클라우드 구조체 정의

import SceneKit

class PointCloud: NSObject {
    
    var n: Int = 0
    var pointCloud: [PointCloudVertex] = []
    
    override init() {
        super.init()
    }
    
    func load(file: String) {
        self.n = 0
        
        do {
            let data = try String(contentsOfFile: file, encoding: .ascii)
            var lines = data.components(separatedBy: "\n")
            
            // Read header
            while !lines.isEmpty {
                let line = lines.removeFirst()
                if line.hasPrefix("element vertex ") {
                    n = Int(line.components(separatedBy: " ")[2])!
                    continue
                }
                if line.hasPrefix("end_header") {
                    break
                }
            }
            
            pointCloud = lines.filter { !$0.isEmpty }.map { line -> PointCloudVertex in
                let elements = line.components(separatedBy: " ")
                return PointCloudVertex(
                    x: Float(elements[0])!,
                    y: Float(elements[1])!,
                    z: Float(elements[2])!,
                    r: Float(elements[3])! / 255.0,
                    g: Float(elements[4])! / 255.0,
                    b: Float(elements[5])! / 255.0
                )
            }
            
            print("Point cloud data loaded: \(n) points")
        } catch {
            print(error)
        }
    }
    
    func getNode(useColor: Bool = true) -> SCNNode {
        let vertices = pointCloud.map { (v: PointCloudVertex) -> PointCloudVertex in
            return useColor ? PointCloudVertex(x: v.x, y: v.y, z: v.z, r: v.r, g: v.g, b: v.b)
                : PointCloudVertex(x: v.x, y: v.y, z: v.z, r: 1.0, g: 1.0, b: 1.0)
        }
        
        return buildNode(points: vertices)
    }
    
    private func buildNode(points: [PointCloudVertex]) -> SCNNode {
        let vertexData = Data(
            bytes: points,
            count: MemoryLayout<PointCloudVertex>.size * points.count
        )
        let positionSource = SCNGeometrySource(
            data: vertexData,
            semantic: .vertex,
            vectorCount: points.count,
            usesFloatComponents: true,
            componentsPerVector: 3,
            bytesPerComponent: MemoryLayout<Float>.size,
            dataOffset: 0,
            dataStride: MemoryLayout<PointCloudVertex>.size
        )
        let colorSource = SCNGeometrySource(
            data: vertexData,
            semantic: .color,
            vectorCount: points.count,
            usesFloatComponents: true,
            componentsPerVector: 3,
            bytesPerComponent: MemoryLayout<Float>.size,
            dataOffset: MemoryLayout<Float>.size * 3,
            dataStride: MemoryLayout<PointCloudVertex>.size
        )
        let elements = SCNGeometryElement(
            data: nil,
            primitiveType: .point,
            primitiveCount: points.count,
            bytesPerIndex: MemoryLayout<Int>.size
        )
        
        let pointsGeometry = SCNGeometry(sources: [positionSource, colorSource], elements: [elements])
        return SCNNode(geometry: pointsGeometry)
    }
}

struct PointCloudVertex {
    var x, y, z: Float
    var r, g, b: Float
}
